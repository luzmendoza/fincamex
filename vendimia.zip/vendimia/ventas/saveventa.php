<?php
include("../database_conection.php");
$info = json_decode(file_get_contents("php://input"));
if(count($info)>0)
{
	$id_cliente = mysqli_real_escape_string($conn,$info->id_cliente);
	$articulos = $info->articulos;
	$total = mysqli_real_escape_string($conn,$info->total);
	$subtotal = mysqli_real_escape_string($conn,$info->subtotal);
	$iva = mysqli_real_escape_string($conn,$info->iva);
	$fecha = mysqli_real_escape_string($conn,$info->fecha);

	$query = "INSERT INTO ventas(id_cliente,total,subtotal,iva,fecha)
			VALUES ('$id_cliente','$total',$subtotal,$iva,'$fecha')";	

	if(mysqli_query($conn,$query))
	{
		$idR = mysql_insert_id();
		foreach($articulos AS $art){
		   	$query = "INSERT INTO ventas_detalle(id_venta,id_articulo,cantidad)
		        VALUES ('$idR','$art->id','$art->cantidad')";
		    mysqli_query($conn,$query);
		}	
		
		echo "Exito";
	}else{
		echo "Fallo ".$query;
	}
}

 ?>