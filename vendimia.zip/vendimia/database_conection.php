<?php
$dsn = 'localhost';
$usuario = 'root';
$contraseña = '';
$bd = 'fincamex';

try {
    $conn = mysqli_connect($dsn,$usuario,$contraseña,$bd);
} catch (PDOException $e) {
    echo 'Falló la conexión: ' . $e->getMessage();
}
?>