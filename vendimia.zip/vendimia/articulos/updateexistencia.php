<?php
include("../database_conection.php");
$info = json_decode(file_get_contents("php://input"));
if(count($info)>0)
{
	$cantidad = mysqli_real_escape_string($conn,$info->cantidad);
	$id = mysqli_real_escape_string($conn,$info->id);
	$opcion = mysqli_real_escape_string($conn,$info->opcion);
	
	if($opcion == "1")//restar del catalogo
	{
		$query = "UPDATE cat_articulos SET existencia = existencia - '$cantidad' WHERE id = $id";
	}else{
		$query = "UPDATE cat_articulos SET existencia = existencia + '$cantidad' WHERE id = $id";
	}	

	if(mysqli_query($conn,$query))
	{
		echo "Exito";
	}else{
		echo "Fallo ".$query;
	}
}

 ?>