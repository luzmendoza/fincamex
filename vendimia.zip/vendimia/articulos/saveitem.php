<?php
include("../database_conection.php");
$info = json_decode(file_get_contents("php://input"));
if(count($info)>0)
{
	$codigo = mysqli_real_escape_string($conn,$info->codigo);
	$descripcion = mysqli_real_escape_string($conn,$info->descripcion);
	$unidad_medida = mysqli_real_escape_string($conn,$info->unidad_medida);
	$precio = mysqli_real_escape_string($conn,$info->precio);
	$existencia = mysqli_real_escape_string($conn,$info->existencia);
	$tasa_iva = mysqli_real_escape_string($conn,$info->tasa_iva);
	$id = mysqli_real_escape_string($conn,$info->id);
	$opcion = mysqli_real_escape_string($conn,$info->opcion);
	
	if($opcion=='1')
	{
		$query = "INSERT INTO cat_articulos(codigo,descripcion,unidad_medida,precio,existencia,tasa_iva)
				VALUES ('$codigo','$descripcion','$unidad_medida','$precio','$existencia','$tasa_iva')";	
	}else{
		$query = "UPDATE cat_articulos SET descripcion = '$descripcion',unidad_medida = '$unidad_medida', 
				precio = '$precio',existencia = '$existencia', tasa_iva= '$tasa_iva' WHERE id = $id";
		
	}
	if(mysqli_query($conn,$query))
	{
		echo "Exito";
	}else{
		echo "Fallo ".$query;
	}
}

 ?>