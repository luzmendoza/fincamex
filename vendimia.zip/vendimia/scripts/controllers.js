var vendimiaControllers = angular.module('vendimiaControllers', []);


vendimiaControllers.controller('ventasCtrl', function($scope, $http) {
    
	 $scope.fecha = new Date();
	
	$scope.id = '';
	$scope.id_cliente = '';
	$scope.rfc = '';
	$scope.telefono = '';
	$scope.domicilio = '';
	$scope.id_articulo = 0;
	$scope.precio = 0;
	$scope.articulos = [];
	$scope.total = 0;
	$scope.totaliva = 0;
	$scope.subtotal = 0;
	$scope.searchText = '';
	$scope.searchItem = '';
	$scope.articulodescripcion  = '';
	$scope.iva = 0;
	$scope.tasa_iva = 0;
	$scope.fecha = '';
	//mostrar pantalla listado
	$scope.listado = function() {
		//mostrar datos
		$http.get("ventas/listaventas.php")
		.then(function (response) {
		    console.log(response);
		    if( (typeof response.data === "object") && (response.data !== null) )
            {
		         $scope.ventas = response.data;
            }else{
                $scope.ventas = {};
            }
		    
		});
		$scope.isnuevo = false;
		$scope.islistado = true;
		
    };
	$scope.listado();
	
	//mostrar pantalla nueva venta
	$scope.addventa = function() {
		$scope.isnuevo = true;
		$scope.islistado = false;
		$scope.id = '';
		$scope.id_cliente = '';
		$scope.rfc = '';
		$scope.telefono = '';
		$scope.domicilio = '';
		$scope.id_articulo = 0;
		$scope.precio = 0;
		$scope.articulos = [];
		$scope.total = 0;
		$scope.totaliva = 0;
		$scope.subtotal = 0;
		$scope.searchText = '';
		$scope.searchItem = '';
		$scope.articulodescripcion  = '';
		$scope.iva = 0;
	    $scope.tasa_iva = 0;
		$scope.fecha = '';
    };
	
	//autocomplete clentes
   $scope.fetchCustomer = function(){
      var searchText_len = $scope.searchText;

	  if(searchText_len==undefined)
	  {
		  return;
	  }
		// Check search text length
	  if(searchText_len.trim().length >= 3){
		 $http({
		   method: 'post',
		   url: 'clientes/getClientes.php',
		   data: {searchText:$scope.searchText}
		 }).then(function successCallback(response) {
			 console.log(response.data);
		   $scope.searchResult = response.data;
		 });
	  }else{
		 $scope.searchResult = {};
	  }           
   }

   // Set value to search box
   $scope.setValue = function(index,$event){
	   console.log($scope.searchResult[index]);
      $scope.searchText = $scope.searchResult[index].id + " " + $scope.searchResult[index].nombre;
      $scope.id_cliente = $scope.searchResult[index].id;
      $scope.rfc = "RFC: "+$scope.searchResult[index].rfc;
	  $scope.telefono = "Teléfono: "+$scope.searchResult[index].telefono;
	  $scope.domicilio = "Domicilio: "+$scope.searchResult[index].domicilio;
      $scope.searchResult = {};
      $event.stopPropagation();
   }

   $scope.searchboxClicked = function($event){
      $event.stopPropagation();
   }

   $scope.containerClicked = function(){
      $scope.searchResult = {};
   }
	
	
	//autocomplete articulos
   $scope.fetchItems = function(){
      var searchItem_len = $scope.searchItem;
	  
	  if(searchItem_len==undefined)
	  {
		  return;
	  }

      // Check search text length
	  if(searchItem_len.trim().length >= 3){
		 $http({
		   method: 'post',
		   url: 'articulos/getArticulos.php',
		   data: {searchText:$scope.searchItem}
		 }).then(function successCallback(response) {
		   $scope.searchResult2 = response.data;
		 });
	  }else{
		 $scope.searchResult2 = {};
	  }
	  
                
   }

   // Set value to search box
   $scope.setValue2 = function(index,$event){
      $scope.searchItem = $scope.searchResult2[index].descripcion + " Iva: " + $scope.searchResult2[index].iva + " Precio: " + $scope.searchResult2[index].precio;
	  $scope.articulodescripcion = $scope.searchResult2[index].descripcion;
      $scope.id_articulo = $scope.searchResult2[index].id;
      $scope.precio = $scope.searchResult2[index].precio;
      $scope.existencia = $scope.searchResult2[index].existencia;
	  $scope.iva = $scope.searchResult2[index].iva;
	  $scope.tasa_iva = $scope.searchResult2[index].tasa_iva;
      $scope.searchResult2 = {};
      $event.stopPropagation();
   }

   $scope.searchboxClicked2 = function($event){
      $event.stopPropagation();
   }

   $scope.containerClicked2 = function(){
      $scope.searchResult2 = {};
   }
   
   //agregar fila a tabla de articulos
   $scope.addArticulo = function(){
       
       if($scope.id_articulo > 0)
       {
           $scope.articulos.push({
            id: $scope.id_articulo,
            descripcion: $scope.articulodescripcion,
            precio: $scope.precio,
            existencia: $scope.existencia,
			iva: $scope.iva,
			tasa_iva: $scope.tasa_iva,
            importe: 0,
            cantidad: 0,
            preciocalculado:0,
            cantidadant:0,
        });
        
        //reiniciar las validaciones
        $scope.frmVentas.articulo.$setUntouched();
        //mostrar mas datos
        $scope.iscalculos = true;
        $scope.isbotonescalculos = true;
        
        $scope.id_articulo = '';
    	$scope.precio = '';
    	$scope.searchItem = '';
		$scope.articulodescripcion  = '';
       }else{
           alert("Seleccione un articulo para agregar");
       }
    }
	
	$scope.addCantidad = function(item){
	    
	    $scope.difcantidad =  item.cantidad -  item.cantidadant;
	    //recuperar existencia
	    $http.get("articulos/getexistencia.php")
		.then(function (response) {
		    console.log(response.data);
		    if( (typeof response.data === "object") && (response.data !== null) )
            {
                console.log("tiene datos");
                $scope.existencia = response.data.existencia;
            }else{
                 console.log("nooo tiene datos");
                $scope.existencia = 0;
            }
		    
		});
	    
	    //validar la existencia
	    if($scope.existencia >= $scope.difcantidad)
	    {
	        //restar existencia del articulo
	        $http.post("articulos/updateexistencia.php",
			{
				'cantidad':$scope.difcantidad,
				'id':item.id,
				'opcion':'1',
			}).then(function successCallback(response) {
				console.log("Bien hecho");
			  }, function errorCallback(response) {
				console.log("Error al actualizar")
			  });
	        //realizar calculos
	       // item.preciocalculado = item.precio * (1 + ($scope.tasafinanciamiento * $scope.plazomaximo)/100);
		   $scope.impuestos = 0;
		   $scope.importesiniva = item.precio * item.cantidad;
		   if(item.tasa_iva=='3')
		   {
			   console.log($scope.importesiniva);
			   console.log(item.iva);
			   $scope.impuestos = $scope.importesiniva *(item.iva /100);
			   console.log($scope.impuestos);
		   }
	        item.importe = $scope.importesiniva + $scope.impuestos;
	        item.existencia -=$scope.difcantidad;
	        item.cantidadant = item.cantidad;
			//calculo de totales
	        $scope.subtotal = $scope.subtotal + $scope.importesiniva;
	        $scope.totaliva = $scope.totaliva + $scope.impuestos;
	        $scope.total = $scope.total + item.importe;
	        
	        console.log( $scope.articulos);
	    }else{
          alert('El artículo seleccionado no cuenta con existencia, favor de verificar');
          if( item.cantidadant == 0)
          {
              var index = $scope.articulos.indexOf(item);
              $scope.articulos.splice(index, 1);
              console.log( $scope.articulos);
          }else{
              item.cantidad = item.cantidadant;
          }
        }
    };

    $scope.deleteitem = function(item){
        if (confirm("¿Seguro que desea eliminar?")) {
            console.log('eliminar');
            var index = $scope.articulos.indexOf(item);
            console.log(index);
            console.log(item);
            $http.post("articulos/updateexistencia.php",
    			{
    				'cantidad':item.cantidad,
    				'id':item.id,
    				'opcion':'2',
    			}).then(function successCallback(response) {
    				console.log("Bien hecho");
    			  }, function errorCallback(response) {
    				console.log("Error al actualizar")
    			  });
    	        //realizar calculos			
			$scope.impuestos = 0;
		   $scope.importesiniva = item.precio * item.cantidad;
		   if(item.tasa_iva=='3')
		   {
			   console.log($scope.importesiniva);
			   console.log(item.iva);
			   $scope.impuestos = $scope.importesiniva *(item.iva /100);
			   console.log($scope.impuestos);
		   }
	        item.importe = $scope.importesiniva + $scope.impuestos;
			
			$scope.subtotal -=  $scope.importesiniva;
	        $scope.totaliva -= $scope.impuestos;
	        $scope.total -= item.importe;
    	    
    	    $scope.articulos.splice(index, 1);
       }
    }
 
	//guardar venta
	$scope.guardar = function() {
        console.log("guardar");
		console.log($scope.fecha);
        
		if($scope.fecha == '')
        {
            alert("La fecha no fue ingresada, favor de verificar");
        }
		else if($scope.id_cliente==0)
        {
            alert("Los datos del cliente no fueron ingresados, favor de verificar");
        }else if($scope.articulos.length == 0)
        {
            alert("Los datos de los articulos no fueron ingresados, favor de verificar");
        }else{
			$http.post("ventas/saveventa.php",
			{
				'id_cliente':$scope.id_cliente,
				'articulos':$scope.articulos,
				'total':$scope.total,
				'subtotal':$scope.subtotal,
				'iva':$scope.totaliva,
				'fecha':$scope.fecha,
				'estatus':'1',
			}).then(function successCallback(response) {
				alert("Bien hecho, tu venta ha sido registrada correctamente");
				//regresar al listado
				$scope.listado();
			  }, function errorCallback(response) {
				alert("Error al guardar la venta")
			  });
		}
		
    };
    
    $scope.cancelarventa = function()
    {
        //regresar al listado
        $scope.listado();
    }
	
});//fin controller

//focus
vendimiaControllers.directive('focusMe', function($timeout) {
  return {
    scope: { trigger: '=focusMe' },
    link: function(scope, element) {
      scope.$watch('trigger', function(value) {
        if(value === true) { 
          //console.log('trigger',value);
          //$timeout(function() {
            element[0].focus();
            scope.trigger = false;
          //});
        }
      });
    }
  };
});

vendimiaControllers.directive('ngEnter', function () {
	console.log("directiva");
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if(event.which === 13) {
                scope.$apply(function (){
                    scope.$eval(attrs.ngEnter);
                });
 
                event.preventDefault();
            }
        });
    };
});



vendimiaControllers.controller('configeneralCtrl', function($scope, $http) {
    
    $scope.date = new Date();
	
	$scope.tasa_financiamiento = '';
	$scope.porc_enganche = '';
	$scope.plazo_maximo = '';
	//mostrar pantalla listado
	$scope.listado = function() {
		//mostrar datos
		$http.get("configeneral/getconfig.php")
		.then(function (response) {
		    console.log(response.data);
		    if( (typeof response.data === "object") && (response.data !== null) )
            {
                console.log("tiene datos");
                $scope.tasa_financiamiento = response.data.tasa_financiamiento;
    		    $scope.porc_enganche = response.data.porc_enganche;
    		    $scope.plazo_maximo = response.data.plazo_maximo;
    		    $scope.opcion = 2;
            }else{
                 console.log("nooo tiene datos");
                  $scope.opcion = 1;
            }
		    
		});
		
    };
	$scope.listado();
	
	
	
	$scope.guardar = function() {
        console.log("guardar");
        var continuar = true;
		if($scope.tasa_financiamiento == '')
		{
			alert("No es posible continuar, debe ingresar tasa de financiamiento");
			continuar = false;
		}
		else if($scope.porc_enganche == '')
		{
			alert("No es posible continuar, debe ingresar porcentaje de enganche");
		}
		else if($scope.plazo_maximo == '')
		{
			alert("No es posible continuar, debe ingresar plazo máximo");
		}else{
			$http.post("configeneral/saveconfig.php",
			{
				'tasa_financiamiento':$scope.tasa_financiamiento,
				'porc_enganche':$scope.porc_enganche,
				'plazo_maximo':$scope.plazo_maximo,
				'opcion':$scope.opcion,
			}).then(function successCallback(response) {
				alert("Bien hecho. La configuración ha sido registrada.");
				
				//reiniciar las validaciones
        	    $scope.formData = {};
                $scope.frmGeneral.$setPristine();
                $scope.frmGeneral.$setUntouched();
				//regresar al listado
				$scope.listado();
			  }, function errorCallback(response) {
				alert("Error al guardar configuracion general")
			  });
		}
    };
	
});

vendimiaControllers.controller('articulosCtrl', function($scope, $http) {
    
     $scope.date = new Date();
	
	$scope.id = '';
	$scope.codigo = '';
	$scope.patterns = {
        letras: /[A-Za-z\s]/,
        decimales:/^([0-9]+\.?[0-9]{0,2})$/
      };
	  	 
	 $scope.isUnique = true;
	 
	 $scope.valUnique = function(event){
		 console.log("wa");
	    console.log(event);
	    //validar la existencia
		if(event.key =="Tab" && $scope.codigo.length > 0)
		{
			$scope.validarCodigo();
		}
		    
		};
		
	 $scope.UniqueE = function(){
		 console.log("wa");
		    $scope.validarCodigo();
		};
		
	$scope.validarCodigo = function()
	{
		$http({
			   method: 'post',
			   url: 'articulos/getValidaCodigo.php',
			   data: {codigo:$scope.codigo}
			 }).then(function successCallback(response) {
			   console.log(response.data);
				if( (typeof response.data === "object") && (response.data !== null) )
				{
					console.log("tiene datos");
					$scope.isUnique = false;
					
				}else{
					 console.log("nooo tiene datos");
					$scope.isUnique = true;
				}
			 });
	}	
      
	//mostrar pantalla listado
	$scope.listado = function() {
		//mostrar datos
		$http.get("articulos/listitems.php")
		.then(function (response) {
		   
		    if( (typeof response.data === "object") && (response.data !== null) )
            {
		         $scope.articulos = response.data;
            }else{
                $scope.articulos = {};
            }
		    
		});
		$scope.isnuevo = false;
		$scope.islistado = true;
		
    };
	$scope.listado();
	
	//mostrar pantalla nuevo 
	$scope.addItem = function() {
	    
	    //reiniciar las validaciones
	    $scope.formData = {};
        $scope.frmArticulos.$setPristine();
        $scope.frmArticulos.$setUntouched();
	    
        $scope.isnuevo = true;
		$scope.islistado = false;
		$scope.isUnique = true;
		$scope.iscodigoedit = false;
		$scope.opcion = '1';
		$scope.descripcion = '';
		$scope.unidad_medida = '';
		$scope.precio = '';
		$scope.existencia = '';
		$scope.tasa_iva = '';
		$scope.codigo = '';
		$scope.id = '';
    };
	$scope.editItem = function(id,codigo,descripcion,unidad_medida,precio,existencia,tasa_iva) {
        $scope.isnuevo = true;
		$scope.islistado = false;
		$scope.iscodigoedit = true;
		$scope.codigo = codigo;
		$scope.descripcion = descripcion;
		$scope.unidad_medida = unidad_medida;
		$scope.precio = precio;
		$scope.existencia = existencia;
		$scope.tasa_iva = tasa_iva;
		$scope.id = id;
		$scope.opcion = '2';
    };
	
	
	$scope.guardar = function() {
        console.log("guardar");
		console.log($scope.tasa_iva);
		console.log($scope.unidad_medida);
		
		if($scope.codigo == '')
		{
			alert("No es posible continuar, debe ingresar código único");
			continuar = false;
		}
		if($scope.descripcion == '')
		{
			alert("No es posible continuar, debe ingresar descripcion");
			continuar = false;
		}
		else if($scope.precio == '')
		{
			alert("No es posible continuar, debe ingresar precio");
		}
		else if($scope.existencia == '')
		{
			alert("No es posible continuar, debe ingresar existencia");
		}
		else if($scope.tasa_iva == '')
		{
			alert("No es posible continuar, debe ingresar iva");
		}
		else if($scope.isUnique == false)
		{
			alert("No es posible continuar, debe ingresar un código único");
		}else{
			console.log($scope.codigo);
			$http.post("articulos/saveitem.php",
			{
				'codigo':$scope.codigo,
				'descripcion':$scope.descripcion,
				'unidad_medida':$scope.unidad_medida,
				'precio':$scope.precio,
				'existencia':$scope.existencia,
				'tasa_iva':$scope.tasa_iva,
				'id':$scope.id,
				'opcion':$scope.opcion,
			}).then(function successCallback(response) {
				alert("Bien hecho. El artículo ha sido registrado correctamente");
				//regresar al listado
				$scope.listado();
			  }, function errorCallback(response) {
				alert("Error al guardar el articulo")
			  });
			
		}
    };
	$scope.deleteItem = function(id) {
        console.log("borrar");
		if(confirm("¿Eliminar el artículo?"))
		{
			$http.post("articulos/deleteitem.php",{'id':id})
			.then(function successCallback(response) {
				alert("Eliminado");
				//regresar al listado
				$scope.listado();
			  }, function errorCallback(response) {
				alert("Error al guardar el articulo")
				return false;
			  });
		}else{
			return false;
		}
    };
	
	
	$scope.cancelar = function()
	{
	    if(confirm("¿Regresar al listado de artículos?"))
		{
           $scope.listado();
		}else{
			return false;
		}
	}
});

vendimiaControllers.controller('clientesCtrl', function($scope, $http) {
    
    $scope.date = new Date();
	
	$scope.id = '';
	$scope.nombreorazon = 'Nombre';
	$scope.regimenmoral = true;
	$scope.regimen = '1';
	//mostrar pantalla listado
	$scope.listado = function() {
		//mostrar datos
		$http.get("clientes/listaclientes.php")
		.then(function (response) {
		   
		    if( (typeof response.data === "object") && (response.data !== null) )
            {
		         $scope.clientes = response.data;
            }else{
                $scope.clientes = {};
            }
		});
		$scope.isnuevo = false;
		$scope.islistado = true;
		
    };
	$scope.listado();
	
	//mostrar pantalla nuevo cliente

	$scope.addcliente = function() {
         
         //limpiar formulario para no mostrar errores anteriores
        $scope.formData = {};
        $scope.frmClientes.$setPristine();
        $scope.frmClientes.$setUntouched();
	    
        $scope.isnuevo = true;
		$scope.islistado = false;
		$scope.nombreorazon = 'Nombre';
		$scope.regimenmoral = true;
		$scope.isrfcvalido = true;
		$scope.regimen = '1';
		$scope.opcion = '1';
		$scope.nombre = '';
		$scope.apellido_paterno = '';
		$scope.apellido_materno = '';
		$scope.rfc = '';
		$scope.telefono = '';
		$scope.correoelectronico = '';
		$scope.calle = '';
		$scope.numero = '';
		$scope.colonia = '';
		$scope.municipio = '';
		$scope.estado = '';
		$scope.codigopostal = '';
		$scope.id = '';
    };
	
	$scope.selectAction = function() {
		console.log($scope.regimen);
		if($scope.regimen == 2)
		{
			$scope.nombreorazon = 'Razon Social';
			$scope.regimenmoral = false;
			$scope.apellido_paterno = '';
			$scope.apellido_materno = '';
		}else{
			$scope.nombreorazon = 'Nombre';
			$scope.regimenmoral = true;
		}
	};
	
	$scope.editcliente = function(id,regimen,nombre,apellido_paterno,apellido_materno,rfc,telefono,correo,calle,numero,colonia,municipio,estado,codigopostal) {
        $scope.isnuevo = true;
		$scope.islistado = false;
		$scope.regimen = regimen;
		$scope.nombre = nombre;
		$scope.apellido_paterno = apellido_paterno;
		$scope.apellido_materno = apellido_materno;
		$scope.rfc = rfc;
		$scope.telefono = telefono;
		$scope.correoelectronico = correo;
		$scope.calle = calle;
		$scope.numero = numero;
		$scope.colonia = colonia;
		$scope.municipio = municipio;
		$scope.estado = estado;
		$scope.codigopostal = codigopostal;
		$scope.id = id;
		$scope.opcion = '2';
		
		$scope.selectAction();
    };
	
	
	$scope.guardar = function() {
        console.log("guardar");
		if($scope.nombre == null)
		{
			alert("No es posible continuar, debe ingresar".$scope.nombreorazon);
		}
		else if($scope.rfc == null)
		{
			alert("No es posible continuar, debe ingresar rfc");
		}else if($scope.isrfcvalido == false)
		{
			alert("No es posible continuar, debe ingresar rfc válido");
		}
		else{
			
			
			if ($scope.numero == ''){$scope.numero = 0;}
			if ($scope.estado == ''){$scope.estado = 0;}
			if ($scope.codigopostal == ''){$scope.codigopostal = 0;}
			
			$http.post("clientes/savecliente.php",
			{
				'regimen':$scope.regimen,
				'nombre':$scope.nombre,
				'apellido_paterno':$scope.apellido_paterno,
				'apellido_materno':$scope.apellido_materno,
				'rfc':$scope.rfc,
				'telefono':$scope.telefono,
				'correoelectronico':$scope.correoelectronico,
				'calle':$scope.calle,
				'numero':$scope.numero,
				'colonia':$scope.colonia,
				'municipio':$scope.municipio,
				'estado':$scope.estado,
				'codigopostal':$scope.codigopostal,
				'id':$scope.id,
				'opcion':$scope.opcion,
			}).then(function successCallback(response) {
				alert("Bien hecho. El cliente ha sido registrado correctamente");
				//regresar al listado
				$scope.listado();
			  }, function errorCallback(response) {
				alert("Error al guardar el cliente")
			  });
		}
    };
	$scope.deletecliente = function(id) {
        console.log("borrar");
		if(confirm("¿Eliminar cliente?"))
		{
			$http.post("clientes/deletecliente.php",{'id':id})
			.then(function successCallback(response) {
				alert("Cliente Eliminado");
				//regresar al listado
				$scope.listado();
			  }, function errorCallback(response) {
				alert("Error al guardar el cliente")
				return false;
			  });
		}else{
			return false;
		}
    };
    
    $scope.cancelar = function()
    {
        if(confirm("¿Regresar al listado de clientes?"))
		{
            $scope.listado();
		}else{
			return false;
		}
    }
	
	
	
	$scope.valRFC = function(event){
		 console.log("wa");
	    console.log(event);
	    //validar la existencia
		if(event.key =="Tab" && $scope.rfc.length > 0)
		{
			var rfcCorrecto = rfcValido($scope.rfc); 
			if (rfcCorrecto) {
				console.log("valido");
				$scope.isrfcvalido = true;
			} else {
				console.log("no valido");
				$scope.isrfcvalido = false;
			}
		}
		    
		};
		
	 $scope.valRFCEnter = function(){
		 console.log("wa");
		    var rfcCorrecto = rfcValido($scope.rfc); 
			if (rfcCorrecto) {
				console.log("valido");
				$scope.isrfcvalido = true;
			} else {
				console.log("no valido");
				$scope.isrfcvalido = false;
			}
		};

});

vendimiaControllers.directive('jqdatepicker', function () {
	console.log("en fecha");
    return {
        restrict: 'A',
        require: 'ngModel',
         link: function (scope, element, attrs, ngModelCtrl) {
            $(element).datepicker({
                dateFormat: 'yy-mm-dd',
				minDate: new Date(),
				 closeText: 'Cerrar',
				  prevText: '<Ant',
				  nextText: 'Sig>',
				  currentText: 'Hoy',
				  monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
				  monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
				  dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
				  dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
				  dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá'],
				  weekHeader: 'Sm',
                onSelect: function (date) {
                    scope.fecha = date;
                    scope.$apply();
                }
            });
        }
    };
});
