<?php
//$conn = mysqli_connect("localhost","root", "","vendimia");
include("../database_conection.php");
$info = json_decode(file_get_contents("php://input"));
if(count($info)>0)
{
	$regimen = mysqli_real_escape_string($conn,$info->regimen);
	$nombre = mysqli_real_escape_string($conn,$info->nombre);
	$apellidopaterno = mysqli_real_escape_string($conn,$info->apellido_paterno);
	$apellidomaterno = mysqli_real_escape_string($conn,$info->apellido_materno);
	$rfc = mysqli_real_escape_string($conn,$info->rfc);
	$telefono = mysqli_real_escape_string($conn,$info->telefono);
	$correoelectronico = mysqli_real_escape_string($conn,$info->correoelectronico);
	$calle = mysqli_real_escape_string($conn,$info->calle);
	$numero = mysqli_real_escape_string($conn,$info->numero);
	$colonia = mysqli_real_escape_string($conn,$info->colonia);
	$municipio = mysqli_real_escape_string($conn,$info->municipio);
	$estado = mysqli_real_escape_string($conn,$info->estado);
	$codigopostal = mysqli_real_escape_string($conn,$info->codigopostal);
	$id = mysqli_real_escape_string($conn,$info->id);
	$opcion = mysqli_real_escape_string($conn,$info->opcion);
	
	if($opcion=='1')
	{
	
		$query = "INSERT INTO cat_clientes(regimen,nombre,apellido_paterno,apellido_materno,rfc,telefono,correo,calle,numero,colonia,municipio,estado,codigo_postal)
				VALUES ('$regimen','$nombre','$apellidopaterno','$apellidomaterno','$rfc','$telefono','$correoelectronico','$calle',$numero,'$colonia','$municipio','$estado',$codigopostal)";	
	}else{
		$query = "UPDATE cat_clientes SET regimen='$regimen', nombre = '$nombre',apellido_paterno = '$apellidopaterno', 
				apellido_materno = '$apellidomaterno',rfc = '$rfc',telefono='$telefono',correo='$correoelectronico',calle='$calle',numero='$numero',colonia='$colonia',municipio='$municipio',
				estado='$estado',codigo_postal = $codigopostal WHERE id = $id";
		
	}
	if(mysqli_query($conn,$query))
	{
		echo "Exito";
	}else{
		echo "Fallo ".$query;
	}
}

 ?>